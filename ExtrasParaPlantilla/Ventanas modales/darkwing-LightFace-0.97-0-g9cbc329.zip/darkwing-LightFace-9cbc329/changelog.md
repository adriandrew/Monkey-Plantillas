LightFace
=========

The following changes have been made to LightFace.

03/21/2012
----------
	+ Updated overlay to have visibility:hidden to work best with Moo 1.4+
	+ Tag updated from .96 to .97

11/17/2010
----------
	+ Updated destroy() method to remove reference to node so that videos stop playing when destroy() is called.
	+ Tag updated from .94 to .96